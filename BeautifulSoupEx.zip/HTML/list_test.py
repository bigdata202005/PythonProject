list = []
print(list)
list.append(1)
list.append(2)
list.append(3)
print(list)
print(type(list))
print(list[0])
t = ['2017-04-30 (일)', '2017-04-05', '정유(丁酉)년 을사(乙巳)월 정해(丁亥)일']
print(t)
print(type(t))
print(t[0])