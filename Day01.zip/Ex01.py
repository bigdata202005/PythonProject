# 파일로 실행하기 --- 반드시 UTF-8로 저장해야 한글이 정확하게 출력됨!!!
height = int(input("몇줄짜리?"))
for i in range(1, height+1):
    print("☆"*i)
print()
