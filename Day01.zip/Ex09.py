# 숫자형
i = 123
j = 123.456
print(i, type(i))  # int
print(j, type(j))  # float

a = 0b10  # 2진수
print(a, type(a))
a = 0o10  # 8진수
print(a, type(a))
a = 0x10  # 16진수
print(a, type(a))
a = 10  # 10진수
print(a, type(a))





