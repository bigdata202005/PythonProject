print('Hello World')
print("Mary's cosmetics")
print('신씨가 소리질렀다. "도둑이야".')
print('"C:\Windows"')
print("안녕하세요.\n만나서\t\t반갑습니다.")
print("오늘은", "일요일")
print(1, 2, 3, 4, 5, 6)
print(1, 2, 3, 4, 5, 6, sep="-", end='\t')
print(11, 22, 33)
print("naver;kakao;sk;samsung"); print("naver", "kakao", "sk", "samsung");
print("naver", "kakao", "sk", "samsung", sep=";")
print("naver", "kakao", "sk", "samsung", sep="/")
print(1 + 2 + 3 + 4)
print(1 + 2 +
      3 + 4)
print(1 + 2 + \
      3 + 4)

print(5/3)
print(5//3)
print(-5/3)
print(-5//3)
