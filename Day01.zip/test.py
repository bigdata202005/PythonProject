height = int(input('몇줄?'))
for i in range(1, height + 1):
    print("★" * i)
print()
