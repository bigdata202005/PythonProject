class FourCal:
    pass    # 아무짓도 하지 않는다.


calc1 = FourCal()
calc2 = FourCal()
calc3 = FourCal()
print(type(calc1))      # <class '__main__.FourCal'>
print(type(calc2))      # <class '__main__.FourCal'>
print(type(calc3))      # <class '__main__.FourCal'>

