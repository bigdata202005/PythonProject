import game.sound.echo
import game.graphic.render

game.sound.echo.echo_test()
game.graphic.render.render_test()

from game.sound.echo import echo_test
echo_test()

from game.graphic.render import *
render_test()


