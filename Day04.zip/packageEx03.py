from game.graphic.render import *
render_test()

