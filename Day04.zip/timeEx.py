import time
print(time)
print(time.time())
print(time.localtime())
print(time.strftime('%Y-%m-%d', time.localtime()))
print(time.strftime('%c', time.localtime()))