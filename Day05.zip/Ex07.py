import webbrowser
webbrowser.open("http://google.com")
webbrowser.open_new("http://google.com")