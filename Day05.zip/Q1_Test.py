from Day05.Q1 import UpgradeCalculator

cal = UpgradeCalculator()
cal.add(10)
cal.minus(7)
print(cal.value) # 10에서 7을 뺀 3을 출력