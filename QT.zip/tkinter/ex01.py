import tkinter
widget = tkinter.Tk()
widget.mainloop()