import turtle

turtle.title('거북아 놀자!!')
turtle.shape('turtle')
turtle.backward(100)
turtle.write('거북아 놀자!!', font=('Times New Roman', 36, 'bold'))
turtle.color('red','green')
turtle.forward(300)
turtle.left(90)
turtle.forward(60)
turtle.left(90)
turtle.forward(330)
turtle.left(90)
turtle.forward(60)
turtle.left(90)
turtle.forward(330)
turtle.exitonclick()

