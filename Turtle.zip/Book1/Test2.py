import turtle as trtl
trtl.shape('turtle')
trtl.forward(0)
trtl.exitonclick()
