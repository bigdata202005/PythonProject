import turtle
turtle.exitonclick()
