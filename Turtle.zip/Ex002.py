import turtle
turtle.forward(0)
turtle.exitonclick()
