import turtle
turtle.forward(0)
turtle.left(30)
turtle.exitonclick()
