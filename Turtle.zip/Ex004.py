import turtle
turtle.forward(0)
turtle.right(90)
turtle.exitonclick()
