import turtle
turtle.shape("turtle")
turtle.forward(0)
turtle.left(90)
#turtle.right(90)
turtle.exitonclick()
