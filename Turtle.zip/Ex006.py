import turtle
turtle.shape("turtle")
turtle.forward(100)
turtle.left(90)
#turtle.right(90)
turtle.exitonclick()
