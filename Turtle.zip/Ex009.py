import turtle
turtle.color('blue')
turtle.shape("turtle")

for i in range(4):
    turtle.left(90)
    turtle.forward(100)
for i in range(4):
    turtle.forward(100)
    turtle.right(90)
turtle.exitonclick()
