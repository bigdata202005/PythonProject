import turtle
turtle.colormode(255)
turtle.color(215, 155, 187)
for i in range(4):
    turtle.forward(50)
    turtle.left(90)
for i in range(4):
    turtle.left(90)
    turtle.forward(50)
for i in range(4):
    turtle.right(90)
    turtle.forward(50)
for i in range(4):
    turtle.forward(50)
    turtle.right(90)

turtle.exitonclick()