import turtle
timmy = turtle
timmy.forward(50)
timmy.left(90)
turtle.forward(50)
turtle.exitonclick()