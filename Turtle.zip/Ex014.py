import turtle
import math
line=10
dash=5
for i in range(10):
    turtle.forward(line)
    turtle.penup()
    turtle.forward(dash)
    turtle.pendown()

turtle.exitonclick()