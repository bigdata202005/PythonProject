import turtle
import math
clrs = ["yellow", "red", "purple", "blue"]
for c in clrs:
    turtle.color(c)
    turtle.forward(50)
    turtle.left(90)

turtle.exitonclick()