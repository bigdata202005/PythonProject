# 거북이를 사용하자
import turtle
# turtle.title('거북아놀자')
# 앞으로 0만큼이동
# turtle.forward(0)
# 일시정지한다.
turtle.done()