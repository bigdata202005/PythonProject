# 거북이를 사용하자
import turtle

print(turtle.shape())
print(turtle.getshapes())
# 커서를 거북이로 만들자
#turtle.shape('turtle')
#turtle.shape('circle')
#turtle.shape('arrow')
#turtle.shape('square')
#turtle.shape('triangle')
#turtle.shape('classic')
#turtle.shape('blank')
print(turtle.shape())

# 앞으로 0만큼이동
turtle.forward(0)
# 일시정지한다.
turtle.done()