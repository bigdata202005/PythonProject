# 거북이를 사용하자
import turtle
# 일시 정지한다.
turtle.done()
