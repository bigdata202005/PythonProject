# 거북이를 사용하자
import turtle
# 클릭시 종료되게 하자
turtle.exitonclick()
