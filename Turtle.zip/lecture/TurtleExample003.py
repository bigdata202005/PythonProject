# 거북이를 사용하자
import turtle
# 윈도우의 제목을 변경해보자
turtle.title('거북아놀자')
# 클릭시 종료되게 하자
turtle.exitonclick()
