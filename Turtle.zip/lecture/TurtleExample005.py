# 거북이를 사용하자
import turtle
# 윈도우의 제목을 변경해보자
turtle.title('거북아놀자')
# 거북이 색상을 변경해보자
turtle.color('black','red')
# 거북이를 나타나게하자
turtle.shape('turtle')
# 클릭시 종료되게 하자
turtle.exitonclick()
