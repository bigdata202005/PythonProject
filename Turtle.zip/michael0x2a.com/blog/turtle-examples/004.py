import turtle

star = turtle.Turtle()

for i in range(5):
    star.forward(50)
    star.right(144)

turtle.done()