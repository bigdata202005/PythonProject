import turtle

painter2 = turtle.Turtle()

painter2.pencolor("#32D486")
painter2.forward(30)

painter2.pencolor("#D6305F")
painter2.forward(30)

turtle.done()