# render.py
# from game.sound.echo import echo_test   # 절대 경로로 지정
from ..sound.echo import *  # 상대 경로로 지정


def render_test():
    print("render")
    echo_test()
