# echo2.py
def echo_test2():
    print ("echo2")